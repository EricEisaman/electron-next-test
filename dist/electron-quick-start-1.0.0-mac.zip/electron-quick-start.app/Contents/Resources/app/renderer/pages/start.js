export default () => (
  <span>This is Next.js speaking!</span>
)